# JobApplicationTracker
Platform to track job applications and tailor resume based on job description
